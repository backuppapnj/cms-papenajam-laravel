@blaze

<div {{ $attributes->class('size-2.5 rounded-full') }}></div>
